# RealtekKiller 1.2 Anti-RAT

A lightweight Windows utility for process inspection, suspicious file checks, and emergency network control.

## How to Run

1. Download the RealtekKiller ZIP archive.
2. Extract the archive to a folder of your choice.
3. Find `RealtekKiller.exe`.
4. Double-click the file to launch the application.
5. If Windows requests permission for certain operations, grant it only if you trust the program and understand what you are authorizing.

You do not need to install Python or build the application to run the included EXE.

## Features

### Process Manager

- View running processes.
- Search for processes by name.
- Open a process's file location when available.
- Terminate selected processes, subject to Windows permissions and application safeguards.

### Suspicious File Checks

- Perform basic heuristic checks on process locations and selected folders.
- Inspect selected locations under `C:\ProgramData`.
- Review suspicious file candidates.

### Quarantine

- Optionally move selected suspicious file candidates to quarantine after confirmation.
- Files should not be automatically deleted simply because they have been flagged as potentially suspicious.

Important: a suspicious file is not necessarily malware. Make sure you understand what a file does before moving it.

### Anti-RAT

- Disconnect active Windows network adapters as an emergency measure.
- Restore adapters disabled by the current RealtekKiller session.
- Run emergency checks on selected user folders, `ProgramData`, and startup locations.

Warning: disconnecting network adapters may interrupt internet and local network access. Some operations may require administrator privileges. These features do not guarantee that a RAT will be detected or stopped.

### System Monitoring

- View CPU and RAM usage.
- Display NVIDIA GPU information when `nvidia-smi` is available.
- Observe selected process-exit events and Task Manager closure events.

### KVRT Support

- Check whether Kaspersky Virus Removal Tool is present.
- Open the official KVRT download page.

Official website: https://www.kaspersky.com/downloads/free-virus-removal-tool

## Important Limitations

RealtekKiller is a supporting security utility, not a full antivirus product.

- Checks may miss malware.
- False positives are possible.
- A clean result does not guarantee that your computer is safe.
- Do not terminate unfamiliar system processes without investigating them.
- Do not quarantine files unless you understand what they are.
- Keep Windows Security or another reputable antivirus enabled for ongoing protection.

## Disclaimer

This software is provided "AS IS." The author does not guarantee detection of every threat and is not responsible for data loss, system interruptions, or consequences resulting from misuse of the application.

Use RealtekKiller responsibly and at your own risk.
